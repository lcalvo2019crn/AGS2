
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Cars and films</title>
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" media="screen" />
  </head>
  <body>
    <div class="contenidor">
      <h1>cars<span style="color: grey">and</span>films</h1>
      <iframe src="anifeta/ani.html" frameborder="none" width="1200px"
      height="600px"></iframe>
        <div class="cubo primero">
            <div class="white">
              <p>Pulp Fiction</p>
            </div>
        </div>
        <div class="cubo segundo">
            <div class="white">
                <p>Taxi Driver</p>
            </div>
        </div>
        <div class="cubo tercero">
            <div class="white">
              <p>Goldfinger</p>
            </div>
        </div>
        <div class="cubo cuarto">
            <div class="white">
              <p>Ghost Busters</p>
            </div>
        </div>
        <div class="cubo quinto">
            <div class="white">
              <p>Mr.Bean</p>
            </div>
        </div>
        <div class="cubo sexto">
            <div class="white">
              <p>Back to the future</p>
            </div>
        </div>
        <div class="cubo septimo">
            <div class="white">
              <p>Knight Rider</p>
            </div>
        </div>
        <div class="cubo octavo">
            <div class="white">
              <p>The A-Team</p>
            </div>
        </div>
        <div class="cubo noveno">
            <div class="white">
              <p>Breaking Bad</p>
            </div>
        </div>
        <img src="img/logo_carsandfilms.png" class="logo">
    </div>

  </body>
</html>
